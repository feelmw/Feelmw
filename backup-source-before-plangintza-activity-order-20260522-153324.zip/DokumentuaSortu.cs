using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using FeelmwLogistika.Plangintza.DatuModeloak;
using System.Text.RegularExpressions;
using WordText = DocumentFormat.OpenXml.Wordprocessing.Text;

namespace FeelmwLogistika.Plangintza.ExelDB
{
    public static class DokumentuaSortu
    {
        public class DokumentuEmaitza
        {
            public string Ruta { get; set; } = "";
            public List<string> Abisuak { get; } = new List<string>();
        }

        public static DokumentuEmaitza Sortu(List<Bidaiak> bidaiak, string izena, string ikastetxea)
        {
            if (bidaiak == null || bidaiak.Count == 0)
            {
                throw new InvalidOperationException("Ez dago Plangintzako daturik dokumentua sortzeko.");
            }

            string plantillaPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Plangintza.docx");
            if (!File.Exists(plantillaPath))
            {
                throw new FileNotFoundException("Ez da aurkitu Word txantiloia: Plangintza.docx", plantillaPath);
            }

            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string outputPath = Path.Combine(desktopPath, $"Plangintza - {izena}.docx");
            File.Copy(plantillaPath, outputPath, true);

            using WordprocessingDocument doc = WordprocessingDocument.Open(outputPath, true);
            MainDocumentPart? mainPart = doc.MainDocumentPart;
            Body? body = mainPart?.Document.Body;
            if (mainPart == null || body == null)
            {
                throw new InvalidOperationException("Word txantiloiak ez dauka dokumentuaren gorputza erabilgarri.");
            }

            List<ExelaSortu.HotelDatuak> hotelak = bidaiak
                .Select(b => HotelaSortu(b))
                .Where(h => !string.IsNullOrWhiteSpace(h.Izena) || !string.IsNullOrWhiteSpace(h.Hiria))
                .ToList();
            List<ExelaSortu.EgunLaburpena> egunak = bidaiak.SelectMany(b => b.EgunLaburpenak).ToList();
            List<ExelaSortu.EkintzaDatuak> ekintzak = bidaiak.SelectMany(b => b.EkintzaDatuak).ToList();
            DokumentuEmaitza emaitza = new DokumentuEmaitza { Ruta = outputPath };

            GehituAbisuaGehiegiBada(body, emaitza.Abisuak, "{{OSTATUA_IZENA_HYPERLINK}}", hotelak.Count, "ostatu");
            GehituAbisuaGehiegiBada(body, emaitza.Abisuak, "{{EGUNA_DATA}}", egunak.Count, "egun");
            GehituAbisuaGehiegiBada(body, emaitza.Abisuak, "{{EGUNA_ORDUA}}", ekintzak.Count, "ekintza");

            Ordezkatu(body, "{{IKASTETXEA}}", new[] { ikastetxea });
            Ordezkatu(body, "{{HIRIA}}", hotelak.Select(h => h.Hiria).ToList());
            OrdezkatuHyperlink(mainPart, body, "{{OSTATUA_IZENA_HYPERLINK}}", hotelak);
            Ordezkatu(body, "{{EGUNA_DATA}}", egunak.Select(e => e.Data).ToList());
            Ordezkatu(body, "{{EGUNA_GOIZA}}", egunak.Select(e => e.Goisa).ToList());
            Ordezkatu(body, "{{EGUNA_ARRATSALDEA}}", egunak.Select(e => e.Arratsaldea).ToList());
            Ordezkatu(body, "{{EGUNA_GAUA}}", egunak.Select(e => e.Gaua).ToList());
            Ordezkatu(body, "{{EGUNA_IZENBURUA}}", egunak.Select(e => e.Data).ToList());
            Ordezkatu(body, "{{EGUNA_ORDUA}}", ekintzak.Select(e => e.Ordua).ToList());
            Ordezkatu(body, "{{EGUNA_DESKRIBAPENA}}", ekintzak.Select(e => e.Deskribapena).ToList());
            GarbituMarkagailuSobratuak(body);

            mainPart.Document.Save();
            return emaitza;
        }

        private static ExelaSortu.HotelDatuak HotelaSortu(Bidaiak bidaia)
        {
            Hotelak? hotela = bidaia.HotelHautatua;
            return new ExelaSortu.HotelDatuak(
                hotela?.Hiria ?? "",
                hotela?.Izena ?? "",
                hotela?.HelbideaUrl ?? "",
                bidaia.EgunKop,
                bidaia.EgunLaburpenak.FirstOrDefault()?.Data ?? ""
            );
        }

        private static void Ordezkatu(Body body, string marka, IReadOnlyList<string> balioak)
        {
            int index = 0;
            foreach (Paragraph paragraph in body.Descendants<Paragraph>().ToList())
            {
                string testua = ParagrafoTestua(paragraph);
                if (!testua.Contains(marka))
                {
                    continue;
                }

                while (testua.Contains(marka))
                {
                    string balioa = index < balioak.Count ? balioak[index] ?? "" : "";
                    testua = LehenengoAldizOrdezkatu(testua, marka, balioa);
                    index++;
                }

                ParagrafoTestuaEzarri(paragraph, testua);
            }
        }

        private static void GehituAbisuaGehiegiBada(Body body, List<string> abisuak, string marka, int datuKop, string izena)
        {
            int markaKop = body.Descendants<Paragraph>().Sum(paragraph => AgerraldiKopurua(ParagrafoTestua(paragraph), marka));
            if (datuKop > markaKop)
            {
                abisuak.Add($"Txantiloiak {markaKop} {izena} leku ditu, baina {datuKop} datu daude. Soberakoak ez dira dokumentuan sartuko.");
            }
        }

        private static void OrdezkatuHyperlink(MainDocumentPart mainPart, Body body, string marka, IReadOnlyList<ExelaSortu.HotelDatuak> hotelak)
        {
            int index = 0;
            foreach (Paragraph paragraph in body.Descendants<Paragraph>().ToList())
            {
                string testua = ParagrafoTestua(paragraph);
                if (!testua.Contains(marka))
                {
                    continue;
                }

                ExelaSortu.HotelDatuak? hotela = index < hotelak.Count ? hotelak[index] : null;
                string izena = hotela?.Izena ?? "";
                string url = hotela?.HelbideaUrl ?? "";
                index++;

                if (testua.Trim() != marka || string.IsNullOrWhiteSpace(url) || !Uri.TryCreate(url, UriKind.Absolute, out Uri? uri))
                {
                    ParagrafoTestuaEzarri(paragraph, testua.Replace(marka, izena));
                    continue;
                }

                HyperlinkRelationship relation = mainPart.AddHyperlinkRelationship(uri, true);
                paragraph.RemoveAllChildren<Run>();
                Run linkRun = new Run(
                    new RunProperties(new RunStyle { Val = "Hyperlink" }),
                    new WordText(izena));

                Hyperlink hyperlink = new Hyperlink(linkRun)
                {
                    Id = relation.Id,
                    History = true
                };

                paragraph.AppendChild(hyperlink);
            }
        }

        private static void GarbituMarkagailuSobratuak(Body body)
        {
            Regex regex = new Regex(@"\{\{[^}]+\}\}");
            foreach (Paragraph paragraph in body.Descendants<Paragraph>())
            {
                string testua = ParagrafoTestua(paragraph);
                if (testua.Contains("{{"))
                {
                    ParagrafoTestuaEzarri(paragraph, regex.Replace(testua, ""));
                }
            }
        }

        private static string ParagrafoTestua(Paragraph paragraph)
        {
            return string.Concat(paragraph.Descendants<WordText>().Select(text => text.Text));
        }

        private static void ParagrafoTestuaEzarri(Paragraph paragraph, string testua)
        {
            List<WordText> zatiak = paragraph.Descendants<WordText>().ToList();
            if (zatiak.Count == 0)
            {
                paragraph.AppendChild(new Run(new WordText(testua)));
                return;
            }

            zatiak[0].Text = testua;
            zatiak[0].Space = SpaceProcessingModeValues.Preserve;
            foreach (WordText zatia in zatiak.Skip(1))
            {
                zatia.Text = "";
            }
        }

        private static string LehenengoAldizOrdezkatu(string testua, string bilatu, string ordezkoa)
        {
            int index = testua.IndexOf(bilatu, StringComparison.Ordinal);
            return index < 0
                ? testua
                : testua.Substring(0, index) + ordezkoa + testua.Substring(index + bilatu.Length);
        }

        private static int AgerraldiKopurua(string testua, string bilatu)
        {
            int count = 0;
            int index = 0;
            while ((index = testua.IndexOf(bilatu, index, StringComparison.Ordinal)) >= 0)
            {
                count++;
                index += bilatu.Length;
            }

            return count;
        }
    }
}
